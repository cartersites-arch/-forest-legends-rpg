FOREST LEGENDS: INTO THE WILD — Adventure 04
Standalone 3D prototype, October 1, 2026.

Play dist/into-the-wild.html via a web server. The release includes its 3D engine and has no network dependencies.
Phone: left pad moves; drag scene to look; gold button interacts. Landscape recommended.
Keyboard: WASD moves, arrow keys look, E interacts, Esc opens journal. Truck W/S accelerates/reverses; A/D steers.

Mission: repair kit -> 3 wood bundles -> repair pickup -> drive north to lake -> fish -> meet Beverly -> find Gerald -> return to campfire.
Energy gradually drops while walking. Fish restores energy; camp restores it fully. Energy has a floor so the prototype cannot trap you in an unwinnable run.
Progress is device-local and separate from Off-Grid Haul. New expedition asks before replacing an existing save.

Build: npm ci; node build.cjs
Tests: node test.cjs and node smoke.cjs (requires Playwright and Chromium; adjust executablePath to your local Chromium).
Nine browser checks cover walking, repair gating, gathering, truck driving/exiting, fishing hit/miss, both companions, campfire completion, pause/save/reload, and responsive layouts. Release smoke checks pointer controls and self-contained build.

LIMITATIONS: Prototype geometry, not photorealistic character models. No sound, advanced vehicle suspension, dynamic weather, combat, or multiplayer. Actual iPhone Safari performance remains unverified. Desktop Chromium tested using software WebGL. Companion pathing is simplified and can cross obstacles. Fishing uses a timing interaction rather than a simulated rod.

Three.js 0.180.0 is MIT licensed; see THREE-LICENSE.txt. Procedural scene assets are original.
