// Appearance based on Jerry's three reference photographs; original images are not embedded.
red.color.set('#eef0e9');red.metalness=.18;red.roughness=.32;metal.metalness=.85;metal.roughness=.22;
const amber=mat('#d69127',.25),lampRed=mat('#a6231e',.28);
for(const side of[-1,1]){
 // Rear dual-wheel pair and broad white dually fender.
 const wheel=cylinder(.5,.5,.28,dark,side*1.47,.55,1.5,truck);wheel.rotation.z=Math.PI/2;
 const hub=cylinder(.21,.21,.3,metal,side*1.49,.55,1.5,truck);hub.rotation.z=Math.PI/2;
 ball(.27,.29,.76,red,side*1.13,1.18,1.48,truck);
 for(let k=0;k<18;k++){const a=k/18*6.28;const tread=box(.28,.055,.16,dark,side*1.47,.55+Math.sin(a)*.5,1.5+Math.cos(a)*.5,truck);tread.rotation.x=-a;}
 box(.17,.15,2.4,metal,side*1.22,.55,-.3,truck);box(.18,.045,2.15,dark,side*1.22,.65,-.3,truck);
 box(.045,.65,.07,red,side*1.04,1.9,-.26,truck);box(.025,.055,.23,dark,side*1.06,1.54,-.77,truck);box(.025,.055,.23,dark,side*1.06,1.54,.17,truck);
 box(.025,.1,.18,amber,side*1.39,1.0,1.1,truck);box(.2,.37,.06,lampRed,side*.92,1.17,2.4,truck);
}
box(1.18,.075,.08,metal,0,1.27,-2.47,truck);box(.075,.4,.08,metal,0,1.26,-2.48,truck);
for(const x of[-.72,-.36,0,.36,.72])ball(.11,.06,.15,amber,x,2.42,-.92,truck);
// Pink and lavender hair, silver pearlescence, and small glints on Beverly's coat.
const pearl=new THREE.MeshPhysicalMaterial({color:'#f0edf4',roughness:.35,metalness:.15,clearcoat:.7,iridescence:.65,iridescenceIOR:1.35});
beverly.traverse(o=>{if(o.material===ivory)o.material=pearl;});
const pinkMane=mat('#e1b4c9',.5),lavenderMane=mat('#b5a5cf',.5);let strand=0;beverly.traverse(o=>{if(o.geometry?.type==='TubeGeometry')o.material=(strand++%3===0)?pinkMane:lavenderMane;});
const sparklePositions=[],sparkleColors=[];for(let i=0;i<260;i++){const a=rand()*6.28,u=rand()*2-1,r=Math.sqrt(1-u*u);sparklePositions.push(Math.cos(a)*r*.535,1.45+u*.66,Math.sin(a)*r*1.15);const c=new THREE.Color([0xffe5b1,0xeedcff,0xcbeafa][i%3]);sparkleColors.push(c.r,c.g,c.b);}const sparkleGeo=new THREE.BufferGeometry();sparkleGeo.setAttribute('position',new THREE.Float32BufferAttribute(sparklePositions,3));sparkleGeo.setAttribute('color',new THREE.Float32BufferAttribute(sparkleColors,3));beverly.add(new THREE.Points(sparkleGeo,new THREE.PointsMaterial({size:.023,vertexColors:true,transparent:true,opacity:.85,depthWrite:false})));
// Broad shoulders and warm brown coat match the larger Bigfoot reference.
gerald.scale.set(1.14,1.12,1.05);fur.color.set('#70543d');skin.color.set('#88705a');
for(const side of[-1,1]){ball(.35,.36,.32,fur,side*.59,2.05,0,gerald);ball(.13,.06,.07,skin,side*.15,2.75,-.39,gerald);}
