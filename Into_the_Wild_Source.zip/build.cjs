const fs=require('fs');const esbuild=require('esbuild');
esbuild.buildSync({entryPoints:['game.js'],bundle:true,loader:{".png":"dataurl"},minify:true,outfile:'bundle.js',legalComments:'eof',target:['safari16','chrome100']});
fs.mkdirSync('dist',{recursive:true});let html=fs.readFileSync('index.html','utf8').replace('<script src="bundle.js"></script>',()=>'<script>'+fs.readFileSync('bundle.js','utf8').replace(/<\/script/gi,'<\\/script')+'</script>');fs.writeFileSync('dist/into-the-wild.html',html);console.log('Built '+Buffer.byteLength(html)+' bytes');
